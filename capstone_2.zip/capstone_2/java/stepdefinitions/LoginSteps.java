package stepdefinitions;

import io.cucumber.java.en.*;
import org.testng.Assert;
import pages.Homepage;
import pages.LoginPage;
import pages.Registration;
import utilities.CommonMethods;
import utilities.configreader;

public class LoginSteps extends CommonMethods {

    configreader config = new configreader();
    Homepage ho;
    LoginPage login;
    Registration reg;

    @Given("I launch the browser")
    public void i_launch_the_browser() {
        launchBrowser("Chrome");
        ho = new Homepage(dr);
        reg = new Registration(dr);
        login = new LoginPage(dr);
    }

    @When("I navigate to the home page")
    public void i_navigate_to_the_home_page() {
        ho.home();
    }

    @When("I register with valid details")
    public void i_register_with_valid_details() {
        String firstname = config.getProperty("first");
        String lastname = config.getProperty("last");
        String email = config.getProperty("email");
        String company = config.getProperty("company");
        String pass = config.getProperty("pass");
        reg.loginUser(firstname, lastname, email, company, pass);
    }

    @When("I navigate to the login page")
    public void i_navigate_to_the_login_page() {
        login.click();
    }

    @When("I enter username and password")
    public void i_enter_username_and_password() {
        String user = config.getProperty("username");
        String pass = config.getProperty("password");
        boolean isLoggedIn = login.loginUser(user, pass, "My account");
        Assert.assertTrue(isLoggedIn, "Login failed");
    }

    @Then("I should see {string} on the dashboard")
    public void i_should_see_on_the_dashboard(String expectedText) {
        Assert.assertTrue(login.verify(expectedText), "Expected text not found");
    }

    @When("I click on logout")
    public void i_click_on_logout() {
        login.logout();
    }

    @Then("I should be logged out successfully")
    public void i_should_be_logged_out_successfully() {
        // Add assertion for logout success
    }
}