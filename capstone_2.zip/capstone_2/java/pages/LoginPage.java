package pages;

import java.time.Duration;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.CommonMethods;

public class LoginPage extends CommonMethods {
    protected WebDriverWait wait;
    Logger log = Logger.getLogger(LoginPage.class);

    @FindBy(linkText = "Log in")
    private WebElement loginLink;

    @FindBy(id = "Email")
    private WebElement emailField;

    @FindBy(id = "Password")
    private WebElement passwordField;

    @FindBy(id = "RememberMe")
    private WebElement rememberMeCheckbox;

    @FindBy(xpath = "//button[text()='Log in']")
    private WebElement loginButton;

    @FindBy(xpath = "//a[@class=\"ico-account\"]")
    private WebElement accountLink;

    @FindBy(linkText = "Log out")
    private WebElement logoutLink;

    public LoginPage (WebDriver dr) {
        this.dr = dr;
        this.wait = new WebDriverWait(dr, Duration.ofSeconds(10));
        PageFactory.initElements(dr, this);
        PropertyConfigurator.configure("src\\test\\resources\\log4j.properties");
    }
    
    public void click() {
        loginLink.click();
    }

    public boolean loginUser(String user, String pwd, String expectedText) {
        log.info("Attempting login for user: " + user);
        emailField.sendKeys(user);
        passwordField.sendKeys(pwd);
        rememberMeCheckbox.click();
        loginButton.click();
        return verify(expectedText);
    }

    public boolean verify(String expectedText) {
        wait.until(ExpectedConditions.visibilityOf(accountLink));
        String actualText = accountLink.getText();
        log.info("Verifying login. Expected: " + expectedText + ", Actual: " + actualText);
        return actualText.equals(expectedText);
    }

    public void logout() {
        log.info("Logging out...");
        wait.until(ExpectedConditions.elementToBeClickable(logoutLink));
        logoutLink.click();
    }
}