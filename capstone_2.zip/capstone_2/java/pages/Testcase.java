package pages;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.*;

public class Testcase {
    @FindBy(xpath = "//div[@class='header-menu']//a[contains(text(),'Computers')]")
    WebElement computerText;

    @FindBy(xpath = "//div[@class='header-menu']//a[contains(text(),'Electronics')]")
    WebElement electronicsText;

    @FindBy(xpath = "//div[@class='header-menu']//a[contains(text(),'Apparel')]")
    WebElement apparelText;

    Logger log = Logger.getLogger(Testcase.class);
    protected WebDriver dr;
    protected WebDriverWait wait;

    public Testcase(WebDriver dr) {
        this.dr = dr;
        this.wait = new WebDriverWait(dr, Duration.ofSeconds(10));
        PageFactory.initElements(dr, this);
        PropertyConfigurator.configure("src\\test\\resources\\log4j.properties");
    }

    public boolean computerText() {
        try {
            wait.until(ExpectedConditions.visibilityOf(computerText));
            return computerText.isDisplayed();
        } catch (TimeoutException | NoSuchElementException e) {
            log.error("Computer text not found: " + e.getMessage());
            return false;
        }
    }

    public boolean electronicsText() {
        try {
            Wait<WebDriver> fluentWait = new FluentWait<>(dr)
                .withTimeout(Duration.ofSeconds(10))
                .pollingEvery(Duration.ofMillis(500))
                .ignoring(NoSuchElementException.class);

            fluentWait.until(driver -> electronicsText.isDisplayed());
            return electronicsText.isDisplayed();
        } catch (TimeoutException | NoSuchElementException e) {
            log.error("Electronics text not found: " + e.getMessage());
            return false;
        }
    }

    public boolean apparelText() {
        try {
            wait.until(ExpectedConditions.visibilityOf(apparelText));
            return apparelText.isDisplayed();
        } catch (TimeoutException | NoSuchElementException e) {
            log.error("Apparel text not found: " + e.getMessage());
            return false;
        }
    }
}