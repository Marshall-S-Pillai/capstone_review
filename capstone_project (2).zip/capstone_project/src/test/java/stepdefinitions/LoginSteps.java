package stepdefinitions;

import io.cucumber.java.en.*;
import org.testng.Assert;
import tests.TestingClass;
import pages.Homepage;
import pages.LoginPage;
import pages.Registration;
import pages.Testcase;
import utilities.CommonMethods;
import utilities.configreader;

public class LoginSteps extends CommonMethods{

    @Given("User is on the login page")     
    public void user_is_on_login_page() {
        TestingClass.initialize("chrome");
        TestingClass.login.navigateToLoginPage();
    }

    @When("User enters valid email {string} and password {string}")
    public void user_enters_valid_credentials(String email, String password) {
        TestingClass.login.enterEmail(email);
        TestingClass.login.enterPassword(password);
    }

    @When("User enters invalid email {string} and password {string}")
    public void user_enters_invalid_credentials(String email, String password) {
        TestingClass.login.enterEmail(email);
        TestingClass.login.enterPassword(password);
    }

    @And("User clicks on the Sign in button")
    public void user_clicks_sign_in() {
        TestingClass.login.clickSignIn();
    }

    @Then("User should be redirected to the dashboard")
    public void user_redirected_to_dashboard() {
        Assert.assertTrue(TestingClass.login.isDashboardVisible(), "Dashboard not visible");
    }

    @Then("An error message {string} should be displayed")
    public void error_message_displayed(String expectedMessage) {
        String actualMessage = TestingClass.login.getErrorMessage();
        Assert.assertEquals(actualMessage, expectedMessage, "Error message mismatch");
        TestingClass.tearDown();
    }
}