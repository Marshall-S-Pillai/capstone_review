package stepdefinitions;

import java.time.Duration;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import pages.LoginPage;
import utilities.base;
import io.cucumber.java.en.*;

public class login_steps extends base {
    LoginPage lp;
    WebDriverWait wait;

    @Given("User is on the login page")
    public void user_is_on_the_login_page() {
        launch_chrome();
        System.out.println("Chrome browser launched");
        lp = new LoginPage(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        lp.click_bt(); // opens login modal
        System.out.println("Opened Login modal");
    }

    @When("User enters username {string}")
    public void user_enters_username(String username) {
        lp.enter_usern(username);
        System.out.println("Entered username: " + username);
    }

    @And("User enters password {string}")
    public void user_enters_password(String password) {
        lp.enter_passw(password);
        System.out.println("Entered password");
    }

    @And("User clicks on the Sign in button")
    public void user_clicks_on_the_sign_in_button() {
        lp.click_login();
        System.out.println("Clicked Sign in button");
    }

    @Then("User should be redirected to the dashboard")
    public void user_should_be_redirected_to_the_dashboard() {
        System.out.println("Login successful: redirected to dashboard");
        lp.click_logout();
        driver.quit();
    }

    @Then("An error message {string} should be displayed")
    public void an_error_message_should_be_displayed(String expectedAlert) {
        wait.until(ExpectedConditions.alertIsPresent());
        String actualAlert = driver.switchTo().alert().getText();
        Assert.assertEquals(actualAlert, expectedAlert, "Alert message mismatch.");
        driver.switchTo().alert().accept();
        System.out.println("Login failed: " + actualAlert);
        driver.quit();
    }
}