package utilities;

 
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.edge.EdgeDriver;

import org.openqa.selenium.OutputType;

import org.openqa.selenium.TakesScreenshot;

import org.apache.commons.io.FileUtils;
 
import java.io.File;

import java.io.IOException;
 
public class base {

    public static WebDriver driver;
 
    // Launch Chrome

    public void launch_chrome() {

        System.setProperty("webdriver.chrome.driver", "chromedriver_v141.exe");

        driver = new ChromeDriver();

        driver.get("https://demo.nopcommerce.com/");

        driver.manage().window().maximize();

    }
 
    // Launch Edge

    public void launch_edge() {

        System.setProperty("webdriver.edge.driver", "msedgedriver_v141.exe");

        driver = new EdgeDriver();
        driver.get("https://demo.nopcommerce.com/");
        driver.manage().window().maximize();

    }
 
    // Close Browser

    public void close_browser() {

        driver.quit();

    }
 
    // Take Screenshot

    //

    public void takeScreenshot(String fileName) {

        TakesScreenshot ts = (TakesScreenshot) driver;

        File src = ts.getScreenshotAs(OutputType.FILE);

        File dest = new File("Screenshot\\" + fileName + ".png");

        try {

            FileUtils.copyFile(src, dest);

            System.out.println("Screenshot saved: " + dest.getAbsolutePath());

        } catch (IOException e) {

            System.out.println("Failed to save screenshot: " + e.getMessage());

        }

    }

}
 