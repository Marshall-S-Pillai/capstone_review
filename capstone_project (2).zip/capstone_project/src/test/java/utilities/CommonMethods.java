package utilities;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CommonMethods {
    protected WebDriver dr;
    protected WebDriverWait wait;
    configreader config = new configreader();
    String url = config.getProperty("url");
    public void launchBrowser(String browser) {
        if (browser.equalsIgnoreCase("chrome")) {
            System.setProperty("webdriver.chrome.driver", "chromedriver_v141.exe");
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--disable-notifications");
            dr = new ChromeDriver(options);
        } else if (browser.equalsIgnoreCase("edge")) {
            System.setProperty("webdriver.edge.driver", "edgedriver_v141.exe");
            EdgeOptions options = new EdgeOptions();
            options.addArguments("--disable-notifications");
            dr = new EdgeDriver(options);
        }
        dr.get(url);
        dr.manage().window().maximize();
        wait = new WebDriverWait(dr, Duration.ofSeconds(10));
    }

    public void closeBrowser() {
        if (dr != null) {
            dr.quit();
        }
    }
}