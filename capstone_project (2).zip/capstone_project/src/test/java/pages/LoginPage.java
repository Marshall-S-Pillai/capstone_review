package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
 
public class LoginPage {
    WebDriver driver;
 
    @FindBy(xpath = "//a[@class='ico-login']")
    WebElement login1;
 
    @FindBy(xpath = "//input[@class='email']")
    WebElement email;
 
    @FindBy(xpath = "//input[@class='password']")
    WebElement password;
 
    @FindBy(xpath = "//button[@class='button-1 login-button']")
    WebElement loginclick;
 
    @FindBy(xpath = "//a[@class='ico-logout']")
    WebElement logoutclick;
 
    public LoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
 
    public void click_bt() {
        login1.click();
    }
 
    public void enter_usern(String username1) {
        email.sendKeys(username1);
    }
 
    public void enter_passw(String password1) {
        password.sendKeys(password1);
    }
 
    public void click_login() {
        loginclick.click();
    }
 
    public void click_logout() {
        logoutclick.click();
    }
}